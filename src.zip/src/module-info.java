/**
 * 
 */
/**
 * @author Asus
 *
 */
module my_proj {
	requires java.desktop;
}