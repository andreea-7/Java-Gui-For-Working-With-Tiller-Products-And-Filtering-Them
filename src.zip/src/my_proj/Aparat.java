package my_proj;

public interface Aparat {

	 public void taie();
	 public void alimenteaza();
}
