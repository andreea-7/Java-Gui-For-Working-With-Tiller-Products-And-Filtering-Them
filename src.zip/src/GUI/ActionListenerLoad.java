package GUI;

import javax.swing.*;

import my_proj.MotoSapa;
import my_proj.UnealtaAgricola;

import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

public class ActionListenerLoad implements ActionListener {

	public static boolean ok = false;

	public void actionPerformed(ActionEvent e) {
		InterfataTest.display.selectAll();
		InterfataTest.display.replaceSelection("");

		
		ArrayList<MotoSapa> list = null;
		
		try (FileInputStream fis = new FileInputStream(InterfataTest.filename.getText());
			    ObjectInputStream ois = new ObjectInputStream(fis);) {

			  list = (ArrayList<MotoSapa>) ois.readObject();
			  InterfataTest.motosape=list;
			  for (MotoSapa a : InterfataTest.motosape) {
					InterfataTest.display.append(a + "\n");
				}
			} catch (IOException ioe) {
			  ioe.printStackTrace();
			} catch (ClassNotFoundException c) {
			  System.out.println("Class not found");
			  c.printStackTrace();
			}
		
	}

}
