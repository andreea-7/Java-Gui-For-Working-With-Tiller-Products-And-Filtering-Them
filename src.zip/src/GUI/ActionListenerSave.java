package GUI;

import javax.swing.*;

import my_proj.MotoSapa;

import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ActionListenerSave implements ActionListener {
	private JTextField filename;
	private JTextArea display;
	public static Object[] k = new MotoSapa[] {};

	public ActionListenerSave(JTextField filename) {
		this.filename = filename;
		//this.display = display;
	}

	public void actionPerformed(ActionEvent e) {
		
		/*try {
	         FileOutputStream fileOut =
	         new FileOutputStream("/tmp/employee.ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(e);
	         out.close();
	         fileOut.close();
	         System.out.printf("Serialized data is saved in /tmp/employee.ser");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	      */
		
		try {
	         FileOutputStream fileOut =
	         new FileOutputStream(filename.getText());
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(InterfataTest.motosape);
	         out.close();
	         fileOut.close();
	         //System.out.printf("Serialized data is saved in /tmp/employee.ser");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	      
		
	}
}
